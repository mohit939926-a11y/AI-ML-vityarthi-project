"""Simple tests. Run from project root:  python tests/test_model.py   (or: pytest)"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.utils import FEATURES, TARGET, load_and_clean, load_model, predict_loan

GOOD = {"Gender": "Male", "Married": "Yes", "Dependents": "0", "Education": "Graduate",
        "Self_Employed": "No", "ApplicantIncome": 5000, "CoapplicantIncome": 1500,
        "LoanAmount": 120, "Loan_Amount_Term": 360, "Credit_History": 1, "Property_Area": "Urban"}
BAD = dict(GOOD, Credit_History=0, LoanAmount=500, ApplicantIncome=2000, CoapplicantIncome=0)


def test_dataset_columns():
    df = load_and_clean()
    assert set(FEATURES + [TARGET]).issubset(df.columns)
    assert df.isnull().sum().sum() == 0


def test_prediction_output_valid():
    pred, prob = predict_loan(load_model(), GOOD)
    assert pred in (0, 1) and 0.0 <= prob <= 1.0


def test_good_applicant_is_approved():
    pred, _ = predict_loan(load_model(), GOOD)
    assert pred == 1


def test_bad_applicant_is_rejected():
    pred, _ = predict_loan(load_model(), BAD)
    assert pred == 0


def test_good_has_higher_probability_than_bad():
    m = load_model()
    assert predict_loan(m, GOOD)[1] > predict_loan(m, BAD)[1]


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn(); print("PASSED:", name)
    print("All tests passed.")
